<?php get_header(); ?>

<div class="container1">
  
	<div id="snap" class="container2-mobile container2">
        	<?php get_template_part('logo');?>
        <!-- End of Header -->
    	<!-- End of Toggle (First navigation) -->

		<div id="content">
        
        <div class="title">
			<h2 id="title-single"><?php if ( have_posts() ) : the_title(); ?></h2>
		</div>
        
        
		<?php  while ( have_posts() ) : the_post(); ?>
			<div id="postmetadata"><?php echo '<small class="thetopic">' ; _e('Topic: '); the_category(', '); the_tags('</small>  <small class="thetags">Tags: '); _e('</small>  <small class="updated"> Updated:  '); the_modified_date('F j, Y'); echo'.</small>';  edit_post_link(' | edit');?>
            </div>
            <div id="single">    
			<?php the_content (); ?>
            
			<?php wp_link_pages(array('next_or_number'=>'number', 'before' => '<div class="pagelink">Pages', 'after' => '</div>',  )); ?>
            
            </div> <!-- End single -->
            
            
        		
			<?php endwhile; ?>
			
            
			<?php  else : ?>
			<?php _e('I tried to find what you are looking for but it does not seem to be here, place change your search criteria.'); ?>         
		
		<?php endif; ?>
		
        <div id="menu2" class="toggle">
            <ul id="menu2-list">
            	 <?php if( get_post_meta($post->ID, 'reference', true) ) : ?><li><h3 class="menu2-title"><a href="#postReferences">Sources</a></h3></li><?php endif; ?>
            	<li><h3 class="menu2-title"><a href="#related">Related posts</a></h3></li>
                <?php if ( have_comments() ) : ?><li><h3 class="menu2-title"><a href="#comments">Discussion</a></h3></li><?php endif; ?>
               <li><h3 class="menu2-title"><a href="#respond">Leave a reply</a></h3></li>
            </ul>
            
            
            
        	<?php if( function_exists('post_references') ); post_references('<h2 id="postReferences_title"  title="Click to collapse">Sources</h2>', '<div id="postReferences">', '</div>'); ?>
            
            
			<div id="related">
            	
            		<ul id="related-list">
                	
    				<?php $orig_post = $post; global $post;$tags = wp_get_post_tags($post->ID);if ($tags) {$tag_ids = array();foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;$related_query = new wp_query(array( 'tag__in' => $tag_ids,'post__not_in' => array($post->ID), 'posts_per_page'=>4, 'caller_get_posts'=>1 ));while( $related_query->have_posts() ) {$related_query->the_post();?>
 
                        <li><a rel="external" href="<?php the_permalink()?>"><?php the_title(); ?></a></li>
                        <?php }}$post = $orig_post;wp_reset_query();?>


					</ul>
                    
                    <?php comments_template(); ?>
            </div>
			
        
        </div><!-- End tabs -->
        
        
		</div><!-- End content -->
        <?php get_template_part('foot'); ?>   
	</div> <!-- End of Container2 -->  
 
<?php get_sidebar();?>         
</div> <!--End Container1 -->  

<?php get_footer(); ?>