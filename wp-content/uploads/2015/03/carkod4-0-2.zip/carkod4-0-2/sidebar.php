<?php if ( wp_is_mobile() ){ // Mobile friendly stuff ?>
<link href="<?php bloginfo('template_url'); ?>/mobile.css" rel="stylesheet" type="text/css" charset="utf-8" />
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/scripts/snap.min.js"></script>
<script type="text/javascript">
// Off-canvas sidebar function		
var snapper=new Snap({element:document.getElementById("snap"),disable:"right"});var myToggleButton=document.getElementById("open-left");myToggleButton.addEventListener("click",function(){if(snapper.state().state=="left"){snapper.close()}else{snapper.open("left")}})
</script>
<?php } else { ; ?>
<link href="<?php bloginfo('template_url'); ?>/desktop.css" rel="stylesheet" type="text/css" charset="utf-8" />
<?php } // End mobile friendly stuff ?>

<div id="sidebar" class="sidebar-mobile">
	
	<ul id="sidebar-list">
    <li><?php get_search_form(); ?></li>
    <li id="archives" ><a href="" id="archives-link" class="section"><?php _e('Archives');?></a>
        
            <ul id="archives-list" class="child">
            <?php wp_get_archives( array(
                'limit'           => '' ,
                'show_post_count' => false,
                'order'           => 'DESC',
                'type'  => 'yearly' ,
                 ) ); ?>
            </ul> 
    </li><!-- End archives list -->
    
		<?php wp_list_pages(array(
            'depth'        => 1,
            'date_format'  => get_option('date_format'),
            'title_li'     => 0,
            'echo'         => 1,
            'authors'      => '',
            'sort_column'  => 'menu_order, post_title',
            'link_before'  => '<span>',
            'link_after'   => '</span>',
            'post_type'    => 'page',
            'post_status'  => 'publish',) ) ; ?>

		<li id="categories"><a href="" id="topics-link" class="section"><?php _e('Topics'); ?></a>
        
            <ul class="child" id="categories-list">
            <?php wp_list_categories('orderby=count&hide_empty=1&title_li=&hierarchical=0&'); ?>
            </ul><!-- End categories list -->
		</li>
        
		<li id="tags" ><a href="" id="tags-link" class="section"><?php _e('Tags'); ?></a>
        
            <?php wp_tag_cloud('orderby=count&smallest=12&largest=12&format=list&number=20&hide_empty=0&title_li=&hierarchical=0&'); ?>
            <!-- End tags list -->
		</li>
		
	</ul><!-- End Sidebar list -->
</div>
