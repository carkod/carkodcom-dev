<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<!-- SEO -->
<?php if (have_posts()):  ?>
<?php if (is_page()): ?>
<title><?php the_title(); echo (' | '); bloginfo('name'); ?></title>
<?php endif; ?>

<?php if (is_single()): ?>
<title><?php the_title(); echo(' - '); $category = get_the_category(); echo $category[0]->cat_name; ?></title>
<?php endif; ?>
    <?php if (is_category() ): ?> 
   <title><?php $category = get_the_category(); echo $category[0]->cat_name; echo (' | '); echo ('Category archives'); ?></title>
   <?php endif; ?>
<?php if (is_tag() ): ?> 
   <title><?php single_tag_title(); echo (' | '); echo ('Tag archives'); ?></title>
   <?php endif; ?>

<?php if ( is_home() ): ?>
<title><?php bloginfo('name'); echo(' | '); bloginfo('description'); ?></title>
<?php endif; else : ?>
<title><?php the_title('',''); echo(' - '); bloginfo('description'); ?></title>
<?php endif; ?> 

<meta http-equiv="content-language" content="<?php bloginfo('language'); ?>" />
<meta http-equiv="contact" content="<?php bloginfo('admin_email'); ?>" />
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php if (is_single() || is_page() ) : if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<meta name="description" content="<?php the_excerpt_rss(); ?>" />
<?php endwhile; endif; elseif(is_home()) : ?>
<meta name="description" content="<?php bloginfo('description'); ?>" />
<?php endif; ?>

<?php if (is_single()) : if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<meta name="keywords" content="<?php $articletags = strip_tags(get_the_tag_list('',', ','')); echo $articletags;
?>" />
<?php endwhile; endif; elseif(is_home()) : ?>
<meta name="keywords" content="carkod,personal,blog,my social,life,works" />
<?php endif; ?>

<?php if (is_single() || is_page() ) : if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<link rel="canonical" href="<?php the_permalink(); ?>" />
<?php endwhile; endif; elseif(is_home()) : ?>
<link rel="canonical" href="<?php bloginfo('url'); ?>" />
<?php endif; ?>

<!-- End SEO -->

<!-- Mobile devices browser configuration -->

<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-touch-fullscreen" content="yes">

<!-- stylesheets -->
<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" charset="utf-8" />
<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/favicon.ico" />


<!-- stylesheets for Mobile devices -->

<!-- stylesheets for other browsers -->

<!-- rss and pingback -->
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!-- scripts  -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/scripts/modernizr.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/scripts/hc-sticky.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-infinitescroll/2.0b2.120519/jquery.infinitescroll.min.js"></script>
<script type="text/javascript">
jQuery( document ).ready(function() {

    });
</script>
</head>
<?php wp_head(); ?>
<body <?php body_class(); ?>>