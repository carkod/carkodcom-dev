<?php get_header(); ?>
<div class="container1">
  
	<div id="snap" class="container2-mobile container2">
    
    	<?php get_template_part('logo');?>
        
        <!-- End of Header -->
		<div id="content">
        
        
        <div id="menu" class="toggle title">
			<ul class="menu-list menu1">
                <li><a id="tab1" href="#latest" title="<?php _e('Those I have written recently');?> "><?php _e('Latest creations');?></a></li>
                <li><a id="tab2" href="#research" title="<?php _e('High quality articles from my own research');?>"><?php _e('Research writings');?></a></li>
                <li><a id="tab3" href="#random" title="<?php _e('Most read articles according to statistics')?>"><?php _e('Random articles');?></a></li>
			</ul>
        <!-- End of Toggle (First navigation) -->

            <div id="latest" class="tabs">
                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <div class="entry">
                    <?php if ( has_post_thumbnail() ) { the_post_thumbnail();}  ?>
                        
                        <h3><a href="<?php the_permalink (); ?>" title="<?php _e('Read Article'); ?>"><?php the_title (); ?></a></h3>
                        <?php the_excerpt (); ?>
                        <div id="postmetadata">
                            <small class="thetopic"><?php  echo "Topic: ";the_category(', ');echo ('</small>  <small class="thetags">') ; the_tags ();?>
                            </small>
                        </div>
                        
                        </div>
                    <?php endwhile; ?> 
                     <div class="pagination" style="text-align:center;">
						<?php posts_nav_link( ' &#183; ', 'previous page', 'next page' ); ?>
					</div>
                     <?php else: ?>
                    <p><?php _e('Sorry, I could not find what you are looking for.'); ?></p>
                    
                <?php endif; ?>
            
            </div>
			
            <!-- End first tab -->
            
            <div id="research" class="tabs">
                <?php $qualityquery = array('meta_key'=>'reference','post_status'=>'publish','post_type'=>'post','orderby'=>'date', 'order'=>'DESC') ; $the_query = new WP_Query( $qualityquery ); while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                    <div class="entry">
                        <?php if ( has_post_thumbnail() ) { the_post_thumbnail();}  ?>
                        <h3><a href="<?php the_permalink (); ?>" title="<?php _e('Read Article'); ?>"><?php the_title (); ?></a></h3>
                        <?php the_excerpt (); ?>
                            <div id="postmetadata">
                            <small class="thetopic"><?php  echo "Topic: ";the_category(', ');echo ('</small>  <small class="thetags">') ; the_tags ();?>
                            </small>
                        </div>
                        
                    </div>
                <?php endwhile; ?>
                 <div class="pagination" style="text-align:center;">
						<?php posts_nav_link( ' &#183; ', 'previous page', 'next page' ); ?>
				 </div>
                     <?php wp_reset_postdata(); ?>
            
            </div>

			<!-- End second tab -->

            <div id="random" class="tabs">
            
                <?php $randomquery = array(
				'orderby' => 'rand',
				'post_status'=>'publish',
				'post_type'=>'post',
				'order'=>'DESC',
				) ; $random_query = new WP_Query( $randomquery ); while ( $random_query->have_posts() ) : $random_query->the_post();?>
                <div class="entry">
                    <?php if ( has_post_thumbnail() ) { the_post_thumbnail();}  ?>
                <h3><a href="<?php the_permalink (); ?>" title="<?php _e('Read Article'); ?>"><?php the_title (); ?></a></h3>
                <?php the_excerpt (); ?>
                <div id="postmetadata">
                            <small class="thetopic"><?php  echo "Topic: ";the_category(', ');echo ('</small>  <small class="thetags">') ; the_tags ();?>
                            </small>
                        </div>
                
                    </div>
                <?php endwhile; ?>
                 <div class="pagination" style="text-align:center;">
						<?php posts_nav_link( ' &#183; ', 'previous page', 'next page' ); ?>
					</div>
                <p><?php _e('Sorry, I could not find what you are looking for.'); ?></p>
                <?php wp_reset_postdata(); ?>
            </div>
			
            <!-- End third tab -->
            
		</div><!-- End tabs -->
        </div><!-- End content -->
        <?php get_template_part('foot'); ?>   
	</div> <!-- End of Container2 -->       
<?php get_sidebar();?>         
</div> <!--End Container1 -->
<?php get_footer(); ?>