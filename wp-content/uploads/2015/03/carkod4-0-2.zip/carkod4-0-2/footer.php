<!-- Scripts -->
<script type="text/javascript">
// Home toggle function
	
jQuery( document ).ready(function() {

// Infinite scroll

$('#content').infinitescroll({
 	
    navSelector  : "div.pagination", // selector for the paged navigation (it will be hidden)
    nextSelector : "div.pagination a",  // selector for the NEXT link (to page 2)
    itemSelector : ".entry" , // selector for all items you'll retrieve
	debug        : true,   // enable debug messaging ( to console.log )
	loading: {
    finishedMsg: "<?php _e('No more articles to load.') ?>",
    img: '<?php bloginfo('template_url'); ?>/images/ajax-loader.gif',
    msg: null,
    msgText: "",
    selector: null,
    speed: 'slow',
    start: undefined
  },

  })
	



// Sidebar accordion
		var sidebar = $("#sidebar") ;
		$("#sidebar li ul").not("#categories-list").hide(); 
		$("#sidebar a.section").on("click", function(event) {
				event.preventDefault();
				var opened = $(this).next("ul")
				opened.toggle();			
				$("#sidebar li ul").not(opened).hide();
				
				
			});
			
// tabs		
		
	$( ".toggle" ).tabs();	
	// Sticky sidebar


$('#sidebar').hcSticky({
    wrapperClassName: 'sidebar-sticky',
	<?php if ( wp_is_mobile() ){ // Mobile friendly stuff ?>
	stickTo:document,
	<?php } ?>
});	
			
    });
</script>

<!-- Google analytics (copy from carkodesign) -->

<?php wp_footer(); ?>
</body>
</html>