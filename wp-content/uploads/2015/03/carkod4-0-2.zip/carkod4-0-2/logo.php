<div id="header">
	<?php if (wp_is_mobile()) { // show the following for mobile devices ?>
    <a href="#sidebar" id="open-left">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
    </a>
    <h1 id="site"><a href="<?php bloginfo('url') ?>" title="Go to Homepage"><?php bloginfo ('name') ; ?></a></h1>
     <?php } else {  // Show the following for desktop computers ?>
    <h1 id="site" class="tree"><a href="<?php bloginfo('url') ?>" title="Go to Homepage"><?php bloginfo ('name') ; ?></a></h1>
    <?php } ?>
    <p><?php bloginfo ('description') ; ?></p>
</div>
